document.addEventListener("DOMContentLoaded", () => {
    let currentIndex = 0;
    const items = document.querySelectorAll('.carousel-item');
    const totalItems = items.length;
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');

    function showItem(index) {
        items[currentIndex].classList.remove('active');
        currentIndex = (index + totalItems) % totalItems;
        items[currentIndex].classList.add('active');
    }

    function showNextItem() {
        showItem(currentIndex + 1);
    }

    function showPrevItem() {
        showItem(currentIndex - 1);
    }

    // Défilement automatique toutes les 3 secondes
    setInterval(showNextItem, 3000);

    // Écouteurs d'événements pour les boutons
    nextBtn.addEventListener('click', showNextItem);
    prevBtn.addEventListener('click', showPrevItem);
});
const countDownDate = new Date("Dec 31, 2024 23:59:59").getTime();

setInterval(function() {
    const now = new Date().getTime();
    const distance = countDownDate - now;
    
    if (distance < 0) {
        document.getElementById("countdown").innerHTML = "Offre expirée";
        return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById("countdown").innerHTML = `${days}j ${hours}h ${minutes}m ${seconds}s`;
}, 1000);


// Sélection des éléments
const quickViewBtn = document.querySelector('.quick-view-btn');
const modal = document.getElementById('quick-view-modal');
const closeModal = document.querySelector('.close-modal');
const modalImage = document.getElementById('modal-image');
const modalTitle = document.getElementById('modal-title');
const modalDescription = document.getElementById('modal-description');
const modalPrice = document.getElementById('modal-price');

// Exemple de produit (les données peuvent venir d'une base de données)
const productData = {
    image: '248.jpg',
    title: 'Dé à 2¨10000 faces',
    description: 'Ceci est une description détaillée du produit.',
    price: '19,99 €'
};

// Fonction pour afficher le modal avec les détails du produit
quickViewBtn.addEventListener('click', () => {
    modalImage.src = productData.image;
    modalTitle.textContent = productData.title;
    modalDescription.textContent = productData.description;
    modalPrice.textContent = `Prix : ${productData.price}`;
    modal.style.display = 'block';
});

// Fonction pour fermer le modal
closeModal.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Fermer le modal en cliquant en dehors du contenu
window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

document.getElementById('apply-filters').addEventListener('click', () => {
    // Récupérer les valeurs des filtres et appliquer le filtrage
    const category = document.getElementById('category-filter').value;
    const minPrice = document.getElementById('price-min').value;
    const maxPrice = document.getElementById('price-max').value;
    // Logique pour filtrer les produits
});



// Fonction pour afficher le toast
function addToCart() {
    const toast = document.getElementById('toast');
    toast.style.display = 'block';
    toast.style.animation = 'fadeInOut 3s forwards'; // Applique l'animation

    // Cache le toast après 3 secondes
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}